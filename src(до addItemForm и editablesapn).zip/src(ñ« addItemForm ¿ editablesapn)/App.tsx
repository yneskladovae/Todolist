import React, {useState} from 'react';
import './App.css';
import {Todolist} from "./components/Todolist/Todolist";
import {v1} from "uuid";
import {FilterType, TasksStateType, TaskType, TodolistsType} from "./Typisation";

function App() {

    const todolistID1 = v1()
    const todolistID2 = v1()

    const [todolists, setTodolists] = useState<Array<TodolistsType>>([
            {id: todolistID1, title: 'What to learn', filter: 'all'},
            {id: todolistID2, title: 'What to buy', filter: 'active'},
    ])

    const [tasks, setTasks] = useState<TasksStateType>({
        [todolistID1]: [
            {id: v1(), title: 'HTML&CSS', isDone: true, isImportant: false},
            {id: v1(), title: 'JS', isDone: true, isImportant: false},
            {id: v1(), title: 'ReactJS', isDone: false, isImportant: false},

        ],
        [todolistID2]: [
            {id: v1(), title: 'Rest API', isDone: true, isImportant: false},
            {id: v1(), title: 'GraphQL', isDone: false, isImportant: false},
        ]
    })

    const removeTask = (todolistId: string, taskId: string) => {
        setTasks({...tasks, [todolistId]: tasks[todolistId].filter(el => el.id !== taskId)});
    }

    const addTask = (todolistId: string, newTitle: string) => {
        const newTask = {id: v1(), title: newTitle, isDone: false, isImportant: false}
        setTasks({...tasks, [todolistId]: [newTask, ...tasks[todolistId]]});
    }

    const changeCheckboxStatus = (todolistId: string, taskId: string, checkboxValue: boolean) => {
        setTasks({
            ...tasks,
            [todolistId]: tasks[todolistId].map(el => el.id === taskId ? {...el, isDone: checkboxValue} : el)
        });
    }

    const changeFilterValue = (todolistId: string, filterValue: FilterType) => {
        setTodolists(todolists.map(el => el.id === todolistId ? {...el, filter: filterValue} : el));
    }

    const isImportantTask = (todolistId: string, taskId: string, isImportantValue: boolean) => {
        setTasks({
            ...tasks,
            [todolistId]: tasks[todolistId].map(el => el.id === taskId ? {...el, isImportant: !isImportantValue} : el)
        });
    }

    const removeTodolist = (todolistId: string) => {
        setTodolists(todolists.filter(el => el.id !== todolistId))
        delete tasks[todolistId]
        setTasks({...tasks})
    }

    return (
        <div className="App">
            {todolists.map(el => {
                const getFilteredTasks = (tasks: TaskType[], filter: FilterType): TaskType[] => {
                    switch (filter) {
                        case 'active' :
                            return tasks.filter(task => !task.isDone)
                        case "completed":
                            return tasks.filter(task => task.isDone)
                        default :
                            return tasks
                    }
                }

                const filterTasks: Array<TaskType> = getFilteredTasks(tasks[el.id], el.filter)
                return (
                    <Todolist
                        key={el.id}
                        todolistId={el.id}
                        title={el.title}
                        tasks={filterTasks}
                        removeTask={removeTask}
                        addTask={addTask}
                        changeFilterValue={changeFilterValue}
                        changeCheckboxStatus={changeCheckboxStatus}
                        isImportantTask={isImportantTask}
                        removeTodolist={removeTodolist}
                        filter={el.filter}
                    />
                )
            })}
        </div>
    );
}

export default App;
