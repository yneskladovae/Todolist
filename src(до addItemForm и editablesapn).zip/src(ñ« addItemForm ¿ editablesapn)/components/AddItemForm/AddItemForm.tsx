import React, {ChangeEvent, KeyboardEvent, useState} from 'react';

export type AddItemFormPropsType = {
    addItem: (title: string) => void
}

export const AddItemForm: React.FC<AddItemFormPropsType> = ({addItem}) => {
    const [inputValue, setInputValue] = useState('');
    const [error, setError] = useState<string | null>(null)

    const addTaskOnClickHandler = () => {
        if (inputValue.trim() !== '') {
            addItem(todolistId, inputValue.trim())
            setInputValue('')
            setError(null)
        } else {
            setError('Title is required')
        }

    }

    const addTaskOnChangeHandler = (e: ChangeEvent<HTMLInputElement>) => {
        setInputValue(e.currentTarget.value)
    }

    const addTaskOnKeyDownHandler = (e: KeyboardEvent<HTMLInputElement>) => {
        if (e.code === 'Enter' && inputValue.trim() !== '') {
            addTask(todolistId, inputValue.trim())
            setInputValue('')
            setError(null)
        }
    }

    return (
        <div>
            <input value={inputValue}
                   onChange={addTaskOnChangeHandler}
                   onKeyDown={addTaskOnKeyDownHandler}
                   className={error ? 'error' : ''}
            />
            <button onClick={addTaskOnClickHandler}>+</button>
            {error && <div className={'error-message '}>Title is required</div>}
        </div>
    );
};