import React, {ChangeEvent, useState, KeyboardEvent} from 'react';
import {TodolistPropsType} from "../../Typisation";
import {AddItemForm} from "../AddItemForm/AddItemForm";


export const Todolist: React.FC<TodolistPropsType> = ({
                                                          title,
                                                          tasks,
                                                          removeTask,
                                                          changeFilterValue,
                                                          addTask,
                                                          changeCheckboxStatus,
                                                          filter,
                                                          isImportantTask,
                                                          todolistId,
                                                          removeTodolist
                                                      }) => {
    const [inputValue, setInputValue] = useState('');
    const [error, setError] = useState<string | null>(null)
    const removeTaskHandler = (taskId: string) => {
        removeTask(todolistId, taskId);
    }
    const addTaskHandler = (newTitle: string) => {
        addTask(todolistId, newTitle)
    }

    const addTaskOnChangeHandler = (e: ChangeEvent<HTMLInputElement>) => {
        setInputValue(e.currentTarget.value)
    }

    const addTaskOnKeyDownHandler = (e: KeyboardEvent<HTMLInputElement>) => {
        if (e.code === 'Enter' && inputValue.trim() !== '') {
            addTask(todolistId, inputValue.trim())
            setInputValue('')
            setError(null)
        }
    }

    const changeCheckboxStatusHandler = (todolistId:string, taskId: string, e: ChangeEvent<HTMLInputElement>) => {
        changeCheckboxStatus(todolistId, taskId, e.currentTarget.checked)
    }

    const isImportantTaskHandler = (todolistId: string, taskId: string, isImportantValue: boolean) => {
        isImportantTask(todolistId, taskId, isImportantValue)
    }

    const removeTodolistHandler = () => {
        removeTodolist(todolistId)
    }

    const setAllFilterValue = () => changeFilterValue(todolistId, 'all');
    const setActiveFilterValue = () => changeFilterValue(todolistId, 'active');
    const setCompletedFilterValue = () => changeFilterValue(todolistId, 'completed');
    const activeFilterAll = filter === 'all' ? 'activeFilterBtn' : '';
    const activeFilterActive = filter === 'active' ? 'activeFilterBtn' : '';
    const activeFilterCompleted = filter === 'completed' ? 'activeFilterBtn' : '';

    return (
        <div>
            <h3>
                <button onClick={removeTodolistHandler}>x</button>
                {title}
            </h3>
            {/*<div>*/}
            {/*    <input value={inputValue}*/}
            {/*           onChange={addTaskOnChangeHandler}*/}
            {/*           onKeyDown={addTaskOnKeyDownHandler}*/}
            {/*           className={error ? 'error' : ''}*/}
            {/*    />*/}
            {/*    <button onClick={addTaskOnClickHandler}>+</button>*/}
            {/*    {error && <div className={'error-message '}>Title is required</div>}*/}
            {/*</div>*/}
            < AddItemForm addItem={addTaskHandler} />
            <ul>
                {tasks.map(el => {
                    return (
                        <li key={el.id} className={el.isImportant ? 'important-task' : el.isDone ? 'is-done' : ''}>
                            <button onClick={() => removeTaskHandler(el.id)}>x</button>
                            <button onClick={() => isImportantTaskHandler(todolistId, el.id, el.isImportant)}>!</button>
                            <input onChange={(event) => changeCheckboxStatusHandler(todolistId, el.id, event)} type="checkbox"
                                   checked={el.isDone}/>
                            <span>{el.title}</span>
                        </li>
                    )
                })}
            </ul>
            <div>
                <button className={activeFilterAll} onClick={setAllFilterValue}>All</button>
                <button className={activeFilterActive} onClick={setActiveFilterValue}>Active</button>
                <button className={activeFilterCompleted} onClick={setCompletedFilterValue}>Completed</button>
            </div>
        </div>
    );
};